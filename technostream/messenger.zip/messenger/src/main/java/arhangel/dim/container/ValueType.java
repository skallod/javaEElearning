package arhangel.dim.container;

/**
 * Какого типа поле
 */
public enum ValueType {
    VAL, // примитивное значение
    REF  // ссылка на объект
}
