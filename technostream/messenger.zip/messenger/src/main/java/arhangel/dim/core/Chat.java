package arhangel.dim.core;

/**
 * А над этим классом надо еще поработать
 */
public class Chat {
    private Long id;
}
