package arhangel.dim.lections.collections;

/**
 *
 */
public class StackException extends Exception {
    public StackException(String msg) {
        super(msg);
    }
}
