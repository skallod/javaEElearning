package arhangel.dim.lections.objects;

/**
 *
 */
public interface ClickListener {

    // do smth on click
    void onClick();
}
