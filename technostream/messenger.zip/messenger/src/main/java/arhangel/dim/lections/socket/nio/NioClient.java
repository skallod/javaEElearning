package arhangel.dim.lections.socket.nio;

import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;
import java.util.Scanner;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

import static java.nio.ByteBuffer.allocate;
import static java.nio.channels.SelectionKey.OP_CONNECT;
import static java.nio.channels.SelectionKey.OP_READ;
import static java.nio.channels.SelectionKey.OP_WRITE;

/**
 *
 */
public class NioClient {
    static final int PORT = 9090;
    static final String ADDRESS = "localhost";
    private ByteBuffer buffer = allocate(16);

    private void run() throws Exception {
        SocketChannel channel = SocketChannel.open();
        channel.configureBlocking(false);
        Selector selector = Selector.open();
        channel.register(selector, OP_CONNECT);
        channel.connect(new InetSocketAddress(ADDRESS, PORT));
        BlockingQueue<String> queue = new ArrayBlockingQueue<>(2);
        new Thread(() -> {
            Scanner scanner = new Scanner(System.in);
            while (true) {
                String line = scanner.nextLine();
                System.out.println("line got");
                if ("q".equals(line)) {
                    System.exit(0);
                }
                try {
                    queue.put(line);
                    System.out.println("puted in queue");
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                SelectionKey key = channel.keyFor(selector);
                key.interestOps(OP_WRITE);
                System.out.println("interested");
                selector.wakeup();
                System.out.println("wakeup");
            }
        }).start();
        while (true) {
            System.out.println("before select");
            selector.select();
            System.out.println("after select");
            for (SelectionKey selectionKey : selector.selectedKeys()) {
                System.out.println("for cicle");
                try {
                    if (selectionKey.isConnectable()) {
                        System.out.println("is connectable");
                        channel.finishConnect();
                        selectionKey.interestOps(OP_WRITE);
                    } else if (selectionKey.isReadable()) {
                        System.out.println("is readable");
                        buffer.clear();
                        channel.read(buffer);
                        System.out.println("Recieved = " + new String(buffer.array()));
                    } else if (selectionKey.isWritable()) {
                        System.out.println("is writable");
                        String line = queue.poll();
                        if (line != null) {
                            System.out.println("line not null");
                            channel.write(ByteBuffer.wrap(line.getBytes()));
                        }
                        selectionKey.interestOps(OP_READ);
                    }
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        }
    }

    public static void main(String[] args) throws Exception {
        new NioClient().run();
    }
}
