package arhangel.dim.lections.threads.counting;

/**
 *
 */
public interface Counter {

    long inc();
}
