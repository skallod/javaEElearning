package arhangel.dim.lections.threads.future;

/**
 *
 */
public class SimpleFuture {

    public static void main(String[] args) {





    }
}
