package arhangel.dim.core.store;

/**
 *
 */
public class Sample {
}
