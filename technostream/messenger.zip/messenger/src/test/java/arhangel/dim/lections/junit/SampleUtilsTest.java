package arhangel.dim.lections.junit;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 *
 */
public class SampleUtilsTest {

    @Test
    public void testIsEmpty() throws Exception {

    }

    @Test
    public void testToHexString() throws Exception {

    }
}
